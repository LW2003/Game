gdjs.Untitled_32sceneCode = {};
gdjs.Untitled_32sceneCode.GDNewBBTextObjects1= [];
gdjs.Untitled_32sceneCode.GDNewBBTextObjects2= [];
gdjs.Untitled_32sceneCode.GDDoorObjects1= [];
gdjs.Untitled_32sceneCode.GDDoorObjects2= [];
gdjs.Untitled_32sceneCode.GDScore_9595LabelObjects1= [];
gdjs.Untitled_32sceneCode.GDScore_9595LabelObjects2= [];
gdjs.Untitled_32sceneCode.GDSkeletonObjects1= [];
gdjs.Untitled_32sceneCode.GDSkeletonObjects2= [];
gdjs.Untitled_32sceneCode.GDNewSprite2Objects1= [];
gdjs.Untitled_32sceneCode.GDNewSprite2Objects2= [];
gdjs.Untitled_32sceneCode.GDFelSpellObjects1= [];
gdjs.Untitled_32sceneCode.GDFelSpellObjects2= [];
gdjs.Untitled_32sceneCode.GDNewTiledSprite2Objects1= [];
gdjs.Untitled_32sceneCode.GDNewTiledSprite2Objects2= [];
gdjs.Untitled_32sceneCode.GDNewSpriteObjects1= [];
gdjs.Untitled_32sceneCode.GDNewSpriteObjects2= [];
gdjs.Untitled_32sceneCode.GDTutorialObjects1= [];
gdjs.Untitled_32sceneCode.GDTutorialObjects2= [];
gdjs.Untitled_32sceneCode.GDNevermoreObjects1= [];
gdjs.Untitled_32sceneCode.GDNevermoreObjects2= [];
gdjs.Untitled_32sceneCode.GDNewLight2Objects1= [];
gdjs.Untitled_32sceneCode.GDNewLight2Objects2= [];
gdjs.Untitled_32sceneCode.GDNewTiledSpriteObjects1= [];
gdjs.Untitled_32sceneCode.GDNewTiledSpriteObjects2= [];


gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDFelSpellObjects1Objects = Hashtable.newFrom({"FelSpell": gdjs.Untitled_32sceneCode.GDFelSpellObjects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDNewSprite2Objects1Objects = Hashtable.newFrom({"NewSprite2": gdjs.Untitled_32sceneCode.GDNewSprite2Objects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDNewLight2Objects1Objects = Hashtable.newFrom({"NewLight2": gdjs.Untitled_32sceneCode.GDNewLight2Objects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDFelSpellObjects1Objects = Hashtable.newFrom({"FelSpell": gdjs.Untitled_32sceneCode.GDFelSpellObjects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDSkeletonObjects1Objects = Hashtable.newFrom({"Skeleton": gdjs.Untitled_32sceneCode.GDSkeletonObjects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDFelSpellObjects1Objects = Hashtable.newFrom({"FelSpell": gdjs.Untitled_32sceneCode.GDFelSpellObjects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDNewTiledSprite2Objects1Objects = Hashtable.newFrom({"NewTiledSprite2": gdjs.Untitled_32sceneCode.GDNewTiledSprite2Objects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDNevermoreObjects1Objects = Hashtable.newFrom({"Nevermore": gdjs.Untitled_32sceneCode.GDNevermoreObjects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDSkeletonObjects1Objects = Hashtable.newFrom({"Skeleton": gdjs.Untitled_32sceneCode.GDSkeletonObjects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDNevermoreObjects1Objects = Hashtable.newFrom({"Nevermore": gdjs.Untitled_32sceneCode.GDNevermoreObjects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDDoorObjects1Objects = Hashtable.newFrom({"Door": gdjs.Untitled_32sceneCode.GDDoorObjects1});
gdjs.Untitled_32sceneCode.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Nevermore"), gdjs.Untitled_32sceneCode.GDNevermoreObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDNevermoreObjects1.length;i<l;++i) {
    if ( !(gdjs.Untitled_32sceneCode.GDNevermoreObjects1[i].getBehavior("PlatformerObject").isMovingEvenALittle()) ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDNevermoreObjects1[k] = gdjs.Untitled_32sceneCode.GDNevermoreObjects1[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDNevermoreObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDNevermoreObjects1 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDNevermoreObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDNevermoreObjects1[i].getBehavior("Animation").setAnimationName("Idle");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Nevermore"), gdjs.Untitled_32sceneCode.GDNevermoreObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDNevermoreObjects1.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDNevermoreObjects1[i].getBehavior("PlatformerObject").isMovingEvenALittle() ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDNevermoreObjects1[k] = gdjs.Untitled_32sceneCode.GDNevermoreObjects1[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDNevermoreObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDNevermoreObjects1 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDNevermoreObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDNevermoreObjects1[i].getBehavior("Animation").setAnimationName("Walk");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Nevermore"), gdjs.Untitled_32sceneCode.GDNevermoreObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDNevermoreObjects1.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDNevermoreObjects1[i].getBehavior("PlatformerObject").isUsingControl("Left") ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDNevermoreObjects1[k] = gdjs.Untitled_32sceneCode.GDNevermoreObjects1[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDNevermoreObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDNevermoreObjects1 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDNevermoreObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDNevermoreObjects1[i].getBehavior("Flippable").flipX(true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Nevermore"), gdjs.Untitled_32sceneCode.GDNevermoreObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDNevermoreObjects1.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDNevermoreObjects1[i].getBehavior("PlatformerObject").isUsingControl("Right") ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDNevermoreObjects1[k] = gdjs.Untitled_32sceneCode.GDNevermoreObjects1[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDNevermoreObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDNevermoreObjects1 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDNevermoreObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDNevermoreObjects1[i].getBehavior("Flippable").flipX(false);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Space");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Nevermore"), gdjs.Untitled_32sceneCode.GDNevermoreObjects1);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDNevermoreObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDNevermoreObjects1[i].getBehavior("Animation").setAnimationName("Jump");
}
}{gdjs.evtTools.sound.playMusic(runtimeScene, "Whoosh Sounds Effects HD (No Copyright).mp3", false, 10, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Nevermore"), gdjs.Untitled_32sceneCode.GDNevermoreObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDNevermoreObjects1.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDNevermoreObjects1[i].getBehavior("PlatformerObject").isFalling() ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDNevermoreObjects1[k] = gdjs.Untitled_32sceneCode.GDNevermoreObjects1[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDNevermoreObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDNevermoreObjects1 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDNevermoreObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDNevermoreObjects1[i].getBehavior("Animation").setAnimationName("falling");
}
}}

}


{


let isConditionTrue_0 = false;
{
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("NewSprite"), gdjs.Untitled_32sceneCode.GDNewSpriteObjects1);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDNewSpriteObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDNewSpriteObjects1[i].putAround(gdjs.evtTools.input.getCursorX(runtimeScene, "", 0), gdjs.evtTools.input.getCursorY(runtimeScene, "", 0), 0, 0);
}
}{gdjs.evtTools.input.hideCursor(runtimeScene);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Nevermore"), gdjs.Untitled_32sceneCode.GDNevermoreObjects1);
gdjs.copyArray(runtimeScene.getObjects("NewSprite"), gdjs.Untitled_32sceneCode.GDNewSpriteObjects1);
gdjs.Untitled_32sceneCode.GDFelSpellObjects1.length = 0;

{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDNevermoreObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDNevermoreObjects1[i].getBehavior("FireBullet").FireTowardPosition((gdjs.Untitled_32sceneCode.GDNevermoreObjects1[i].getPointX("")) + 100, (gdjs.Untitled_32sceneCode.GDNevermoreObjects1[i].getPointY("")) + 100, gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDFelSpellObjects1Objects, (( gdjs.Untitled_32sceneCode.GDNewSpriteObjects1.length === 0 ) ? 0 :gdjs.Untitled_32sceneCode.GDNewSpriteObjects1[0].getPointX("")), (( gdjs.Untitled_32sceneCode.GDNewSpriteObjects1.length === 0 ) ? 0 :gdjs.Untitled_32sceneCode.GDNewSpriteObjects1[0].getPointY("")), 500, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "magic sound effect.mp3", false, 10, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("NewLight2"), gdjs.Untitled_32sceneCode.GDNewLight2Objects1);
gdjs.copyArray(runtimeScene.getObjects("NewSprite2"), gdjs.Untitled_32sceneCode.GDNewSprite2Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDNewSprite2Objects1Objects, gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDNewLight2Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDNewSprite2Objects1 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDNewSprite2Objects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDNewSprite2Objects1[i].getBehavior("Animation").setAnimationName("hover");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("FelSpell"), gdjs.Untitled_32sceneCode.GDFelSpellObjects1);
gdjs.copyArray(runtimeScene.getObjects("Skeleton"), gdjs.Untitled_32sceneCode.GDSkeletonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDFelSpellObjects1Objects, gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDSkeletonObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Score_Label"), gdjs.Untitled_32sceneCode.GDScore_9595LabelObjects1);
/* Reuse gdjs.Untitled_32sceneCode.GDSkeletonObjects1 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDSkeletonObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDSkeletonObjects1[i].deleteFromScene(runtimeScene);
}
}{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber((runtimeScene.getGame().getVariables().getFromIndex(0).getAsNumber() + 1));
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDScore_9595LabelObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDScore_9595LabelObjects1[i].getBehavior("Text").setText((runtimeScene.getGame().getVariables().getFromIndex(0).getAsString()));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("FelSpell"), gdjs.Untitled_32sceneCode.GDFelSpellObjects1);
gdjs.copyArray(runtimeScene.getObjects("NewTiledSprite2"), gdjs.Untitled_32sceneCode.GDNewTiledSprite2Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDFelSpellObjects1Objects, gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDNewTiledSprite2Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDFelSpellObjects1 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDFelSpellObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDFelSpellObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Nevermore"), gdjs.Untitled_32sceneCode.GDNevermoreObjects1);
gdjs.copyArray(runtimeScene.getObjects("Skeleton"), gdjs.Untitled_32sceneCode.GDSkeletonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDNevermoreObjects1Objects, gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDSkeletonObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDNevermoreObjects1 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDNevermoreObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDNevermoreObjects1[i].setPosition(-(977),987);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Door"), gdjs.Untitled_32sceneCode.GDDoorObjects1);
gdjs.copyArray(runtimeScene.getObjects("Nevermore"), gdjs.Untitled_32sceneCode.GDNevermoreObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDNevermoreObjects1Objects, gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDDoorObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Level 2", false);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playMusic(runtimeScene, "Dark Fantasy TikTok Song.mp3", true, 10, 1);
}}

}


{


let isConditionTrue_0 = false;
{
}

}


};

gdjs.Untitled_32sceneCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Untitled_32sceneCode.GDNewBBTextObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewBBTextObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDDoorObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDDoorObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDScore_9595LabelObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDScore_9595LabelObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDSkeletonObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDSkeletonObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewSprite2Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewSprite2Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDFelSpellObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDFelSpellObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewTiledSprite2Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewTiledSprite2Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewSpriteObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewSpriteObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDTutorialObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDTutorialObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDNevermoreObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDNevermoreObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewLight2Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewLight2Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewTiledSpriteObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewTiledSpriteObjects2.length = 0;

gdjs.Untitled_32sceneCode.eventsList0(runtimeScene);

return;

}

gdjs['Untitled_32sceneCode'] = gdjs.Untitled_32sceneCode;
